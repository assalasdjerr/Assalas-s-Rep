"use client"

import { useState, useEffect } from "react"
import { usePathname } from "next/navigation"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useSelector, useDispatch } from "react-redux"
import { logout } from "../redux/authSlice"
import "../styles/Header.css"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  const dispatch = useDispatch()
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated)
  const user = useSelector((state) => state.auth.user)

  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const handleLogout = () => {
    dispatch(logout())
    localStorage.removeItem("isAuthenticated")
    router.push("/login")
  }

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  if (!isMounted) {
    return null
  }

  return (
    <header className="header">
      <div className="header-container">
        <div className="header-content">
          <Link href="/" className="logo">
            Assalas Djerroud
          </Link>

          <nav className="desktop-nav">
            {isAuthenticated && (
              <>
                <Link href="/" className={`nav-link ${pathname === "/" ? "active" : ""}`}>
                  Accueil
                </Link>
                <Link
                  href="/projets"
                  className={`nav-link ${pathname === "/projets" || pathname.startsWith("/projets/") ? "active" : ""}`}
                >
                  Projets
                </Link>
                <Link
                  href="/temoignages"
                  className={`nav-link ${pathname === "/temoignages" || pathname.startsWith("/temoignages/") ? "active" : ""}`}
                >
                  Témoignages
                </Link>
              </>
            )}

            {isAuthenticated ? (
              <div className="auth-section">
                <span className="user-greeting">Bonjour, {user?.prenom}</span>
                <button onClick={handleLogout} className="logout-button">
                  Déconnexion
                </button>
              </div>
            ) : (
              <div className="auth-section">
                <Link href="/login" className={`nav-link ${pathname === "/login" ? "active" : ""}`}>
                  Connexion
                </Link>
                <Link href="/inscription" className="signup-button">
                  Inscription
                </Link>
              </div>
            )}
          </nav>

          <button className="mobile-menu-button" onClick={toggleMenu}>
            {isMenuOpen ? <span className="menu-icon">✕</span> : <span className="menu-icon">☰</span>}
          </button>
        </div>

        {isMenuOpen && (
          <nav className="mobile-nav">
            {isAuthenticated && (
              <>
                <Link href="/" className={`mobile-nav-link ${pathname === "/" ? "active" : ""}`}>
                  Accueil
                </Link>
                <Link
                  href="/projets"
                  className={`mobile-nav-link ${pathname === "/projets" || pathname.startsWith("/projets/") ? "active" : ""}`}
                >
                  Projets
                </Link>
                <Link
                  href="/temoignages"
                  className={`mobile-nav-link ${pathname === "/temoignages" || pathname.startsWith("/temoignages/") ? "active" : ""}`}
                >
                  Témoignages
                </Link>
              </>
            )}

            {isAuthenticated ? (
              <div className="mobile-auth-section">
                <div className="mobile-user-greeting">Bonjour, {user?.prenom}</div>
                <button onClick={handleLogout} className="mobile-logout-button">
                  Déconnexion
                </button>
              </div>
            ) : (
              <div className="mobile-auth-section">
                <Link href="/login" className={`mobile-nav-link ${pathname === "/login" ? "active" : ""}`}>
                  Connexion
                </Link>
                <Link href="/inscription" className="mobile-signup-button">
                  Inscription
                </Link>
              </div>
            )}
          </nav>
        )}
      </div>
    </header>
  )
}
