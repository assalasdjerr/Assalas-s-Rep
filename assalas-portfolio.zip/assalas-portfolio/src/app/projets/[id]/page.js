"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import "../../../styles/ProjetDetail.css";

export default function ProjetDetail({ params }) {
  const router = useRouter();
  const { id } = params;
  const [projet, setProjet] = useState(null);

  useEffect(() => {
    const isAuthenticated = localStorage.getItem("isAuthenticated");
    if (!isAuthenticated) {
      router.push("/login");
      return;
    }

    if (id) {
      // Simuler une récupération de données
      const projets = [
        {
          id: 1,
          titre: "Application de Gestion de Tâches",
          description:
            "Une application web permettant de gérer ses tâches quotidiennes avec des fonctionnalités de création, modification et suppression.",
          descriptionLongue:
            "Cette application de gestion de tâches a été développée pour aider les utilisateurs à organiser leur travail quotidien. Elle permet de créer des tâches, de les assigner à différentes catégories, de définir des dates d'échéance et des priorités. Les utilisateurs peuvent également marquer les tâches comme terminées, les modifier ou les supprimer. L'interface utilisateur est intuitive et responsive, permettant une utilisation sur différents appareils.",
          image: "/projet-gestion-taches.png",
          technologies: ["React", "Node.js", "MongoDB", "Express"],
          fonctionnalites: [
            "Création, modification et suppression de tâches",
            "Catégorisation des tâches",
            "Définition de priorités",
            "Filtrage et recherche",
            "Interface responsive",
          ],
          github: "https://github.com/assalasdjerr/Assalas-s-Rep",
        },
        {
          id: 2,
          titre: "Site E-commerce",
          description:
            "Un site e-commerce complet avec panier d'achat, paiement en ligne et gestion des commandes.",
          descriptionLongue:
            "Ce site e-commerce offre une expérience d'achat complète aux utilisateurs. Il comprend un catalogue de produits, un système de recherche et de filtrage, un panier d'achat, et un processus de paiement sécurisé via Stripe. Les administrateurs peuvent gérer les produits, les stocks, et suivre les commandes via un tableau de bord dédié. Le site est entièrement responsive et optimisé pour les performances.",
          image: "/ecommerce-projet.png",
          technologies: ["Next.js", "Redux", "Stripe", "Firebase"],
          fonctionnalites: [
            "Catalogue de produits",
            "Panier d'achat",
            "Paiement en ligne sécurisé",
            "Gestion des commandes",
            "Tableau de bord administrateur",
          ],
          github: "https://github.com/assalasdjerr/Assalas-s-Rep",
        },
        {
          id: 3,
          titre: "Application Météo",
          description:
            "Une application météo qui affiche les prévisions en temps réel pour n'importe quelle ville dans le monde.",
          descriptionLongue:
            "Cette application météo permet aux utilisateurs de consulter les prévisions météorologiques en temps réel pour n'importe quelle ville dans le monde. Elle utilise l'API OpenWeather pour récupérer les données météorologiques actuelles et les prévisions sur 5 jours. L'interface utilisateur est simple et intuitive, avec des icônes représentant les différentes conditions météorologiques et des graphiques pour visualiser l'évolution des températures.",
          image: "/projet-meteo.webp",
          technologies: ["React", "OpenWeather API", "CSS", "Axios"],
          fonctionnalites: [
            "Recherche de villes",
            "Affichage des conditions météorologiques actuelles",
            "Prévisions sur 5 jours",
            "Graphiques de température",
            "Géolocalisation",
          ],
          github: "https://github.com/assalasdjerr/Assalas-s-Rep",
        },
      ];

      const projetTrouve = projets.find((p) => p.id === Number.parseInt(id));
      setProjet(projetTrouve);
    }
  }, [id, router]);

  if (!projet) {
    return <div className="loading">Chargement...</div>;
  }

  return (
    <main className="projet-detail-container">
      <Link href="/projets" className="back-link">
        &larr; Retour aux projets
      </Link>

      <div className="projet-detail-card">
        <div className="projet-detail-image">
          <Image
            src={projet.image || "/placeholder.svg"}
            alt={projet.titre}
            width={800}
            height={500}
          />
        </div>

        <div className="projet-detail-content">
          <h1 className="projet-detail-title">{projet.titre}</h1>

          <div className="projet-detail-section">
            <h2 className="section-subtitle">Description</h2>
            <p className="projet-detail-description">
              {projet.descriptionLongue}
            </p>
          </div>

          <div className="projet-detail-section">
            <h2 className="section-subtitle">Technologies utilisées</h2>
            <div className="technologies-list">
              {projet.technologies.map((tech, index) => (
                <span key={index} className="technology-tag">
                  {tech}
                </span>
              ))}
            </div>
          </div>

          <div className="projet-detail-section">
            <h2 className="section-subtitle">Fonctionnalités</h2>
            <ul className="features-list">
              {projet.fonctionnalites.map((fonc, index) => (
                <li key={index} className="feature-item">
                  {fonc}
                </li>
              ))}
            </ul>
          </div>

          <div className="projet-links">
            <a
              href={projet.github}
              target="_blank"
              rel="noopener noreferrer"
              className="github-link"
            >
              Voir sur GitHub
            </a>
          </div>
        </div>
      </div>
    </main>
  );
}
