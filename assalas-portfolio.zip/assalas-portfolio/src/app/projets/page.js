"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import "../../styles/Projets.css";

export default function Projets() {
  const router = useRouter();

  useEffect(() => {
    const isAuthenticated = localStorage.getItem("isAuthenticated");
    if (!isAuthenticated) {
      router.push("/login");
    }
  }, [router]);

  const projets = [
    {
      id: 1,
      titre: "Application de Gestion de Tâches",
      description:
        "Une application web permettant de gérer ses tâches quotidiennes avec des fonctionnalités de création, modification et suppression.",
      image: "/projet-gestion-taches.png",
      technologies: ["React", "Node.js", "MongoDB", "Express"],
    },
    {
      id: 2,
      titre: "Site E-commerce",
      description:
        "Un site e-commerce complet avec panier d'achat, paiement en ligne et gestion des commandes.",
      image: "/ecommerce-projet.png",
      technologies: ["Next.js", "Redux", "Stripe", "Firebase"],
    },
    {
      id: 3,
      titre: "Application Météo",
      description:
        "Une application météo qui affiche les prévisions en temps réel pour n'importe quelle ville dans le monde.",
      image: "/projet-meteo.webp",
      technologies: ["React", "OpenWeather API", "CSS", "Axios"],
    },
  ];

  return (
    <main className="projets-container">
      <h1 className="page-title">Mes Projets</h1>

      <div className="projets-grid">
        {projets.map((projet) => (
          <div key={projet.id} className="projet-card">
            <div className="projet-image">
              <Image
                src={projet.image || "/placeholder.svg"}
                alt={projet.titre}
                width={500}
                height={300}
              />
            </div>

            <div className="projet-content">
              <h2 className="projet-title">{projet.titre}</h2>
              <p className="projet-description">{projet.description}</p>

              <div className="projet-technologies">
                <h3 className="technologies-title">Technologies utilisées:</h3>
                <div className="technologies-list">
                  {projet.technologies.map((tech, index) => (
                    <span key={index} className="technology-tag">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              <Link
                href={`/projets/${projet.id}`}
                className="view-details-button"
              >
                Voir les détails
              </Link>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
