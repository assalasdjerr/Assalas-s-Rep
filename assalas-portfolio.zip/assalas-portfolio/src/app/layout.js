import { Inter } from "next/font/google";
import "../styles/globals.css";
import { ReduxProvider } from "../redux/provider";
import Header from "../components/Header";
import Footer from "../components/Footer";
import "../styles/Layout.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Assalas Djerroud | Portfolio",
  description: "Portfolio professionnel d'Assalas Djerroud",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body className={inter.className}>
        <ReduxProvider>
          <div className="layout">
            <Header />
            <div className="main-content">{children}</div>
            <Footer />
          </div>
        </ReduxProvider>
      </body>
    </html>
  );
}

import "./globals.css";
