"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import "../styles/Home.css";

export default function Home() {
  const router = useRouter();

  useEffect(() => {
    const isAuthenticated = localStorage.getItem("isAuthenticated");
    if (!isAuthenticated) {
      router.push("/login");
    }
  }, [router]);

  return (
    <main className="home-container">
      <section className="profile-section">
        <div className="profile-image-container">
          <div className="profile-image">
            <Image
              src="/image.jpeg"
              alt="Assalas Djerroud"
              width={256}
              height={256}
              className="image"
            />
          </div>
        </div>

        <div className="profile-info">
          <h1 className="profile-name">Assalas Djerroud</h1>
          <h2 className="profile-title">Développeur Web</h2>

          <div className="profile-description">
            <p>Bonjour et bienvenue sur mon portfolio !</p>
            <p>
              Je m&apos;appelle Assalas Djerroud, j&apos;ai 24 ans, né le 28
              mars 2001, et je suis actuellement étudiant en programmation
              informatique à La Cité collégiale d&apos;Ottawa. Je suis passionné
              par le développement web, les technologies émergentes et tout ce
              qui touche à l&apos;innovation numérique.
            </p>
            <p>
              Sur le point d&apos;obtenir mon diplôme, je combine mes études
              avec une expérience professionnelle enrichissante en tant que
              manager chez Techtron Canada, une boutique spécialisée dans la
              vente et le conseil de produits technologiques. Cette expérience
              me permet non seulement d&apos;affiner mes compétences techniques,
              mais aussi de développer des qualités essentielles comme la
              gestion d&apos;équipe, la relation client, et la résolution de
              problèmes en situation réelle.
            </p>
            <p>
              Rigoureux, curieux et toujours prêt à apprendre, je cherche
              constamment à repousser mes limites et à mettre mes connaissances
              en pratique dans des projets concrets. Mon objectif est de
              contribuer activement à des environnements dynamiques, où je peux
              allier créativité, logique, et technologies de pointe.
            </p>
          </div>
        </div>
      </section>

      <section className="skills-section">
        <h2 className="section-title">Mes compétences</h2>

        <div className="skills-grid">
          <div className="skill-card">
            <h3 className="skill-title">Développement Frontend</h3>
            <ul className="skill-list">
              <li>HTML5, CSS3, JavaScript</li>
              <li>React.js, Next.js</li>
              <li>Redux, Context API</li>
              <li>CSS, SASS, Bootstrap</li>
            </ul>
          </div>

          <div className="skill-card">
            <h3 className="skill-title">Développement Backend</h3>
            <ul className="skill-list">
              <li>Node.js, Express</li>
              <li>MongoDB, MySQL</li>
              <li>API REST</li>
              <li>Firebase</li>
            </ul>
          </div>

          <div className="skill-card">
            <h3 className="skill-title">Outils & Méthodologies</h3>
            <ul className="skill-list">
              <li>Git, GitHub</li>
              <li>VS Code, Postman</li>
              <li>Méthodologie Agile</li>
              <li>Responsive Design</li>
            </ul>
          </div>
        </div>
      </section>
    </main>
  );
}
