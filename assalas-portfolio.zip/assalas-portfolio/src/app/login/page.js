"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useDispatch, useSelector } from "react-redux"
import { login } from "../../redux/authSlice"
import Link from "next/link"
import "../../styles/Auth.css"

export default function Login() {
  const router = useRouter()
  const dispatch = useDispatch()
  const users = useSelector((state) => state.auth.users)

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })

  const [errors, setErrors] = useState({})
  const [loginError, setLoginError] = useState("")

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value,
    })

    // Effacer l'erreur lorsque l'utilisateur commence à corriger
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: "",
      })
    }

    // Effacer l'erreur de connexion
    if (loginError) {
      setLoginError("")
    }
  }

  const validateForm = () => {
    const newErrors = {}

    if (!formData.email.trim()) {
      newErrors.email = "L'email est requis"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "L'email est invalide"
    }

    if (!formData.password) {
      newErrors.password = "Le mot de passe est requis"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    if (validateForm()) {
      const user = users.find((user) => user.email === formData.email)

      if (user && user.password === formData.password) {
        dispatch(login(user))
        localStorage.setItem("isAuthenticated", "true")
        router.push("/")
      } else {
        setLoginError("Email ou mot de passe incorrect")
      }
    }
  }

  return (
    <main className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <h1 className="auth-title">Connexion</h1>
          <p className="auth-subtitle">Connectez-vous pour accéder au portfolio</p>
        </div>

        {loginError && <div className="error-alert">{loginError}</div>}

        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email" className="form-label">
              Email
            </label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              className={`form-input ${errors.email ? "error" : ""}`}
            />
            {errors.email && <p className="error-message">{errors.email}</p>}
          </div>

          <div className="form-group">
            <label htmlFor="password" className="form-label">
              Mot de passe
            </label>
            <input
              id="password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              className={`form-input ${errors.password ? "error" : ""}`}
            />
            {errors.password && <p className="error-message">{errors.password}</p>}
          </div>

          <div className="form-group">
            <button type="submit" className="submit-button">
              Se connecter
            </button>
          </div>
        </form>

        <div className="auth-footer">
          <p>
            Vous n&apos;avez pas de compte ?{" "}
            <Link href="/inscription" className="auth-link">
              S&apos;inscrire
            </Link>
          </p>
        </div>
      </div>
    </main>
  )
}
